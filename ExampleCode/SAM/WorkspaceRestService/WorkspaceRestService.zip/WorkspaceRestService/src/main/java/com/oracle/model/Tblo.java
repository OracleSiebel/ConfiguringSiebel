package com.oracle.model;

public final class Tblo {

	public  String tblo;
	public  String driverClassName;
	public  String intBranchName;

	public Tblo() {
		super();
	}

	public  String getTblo() {
		return tblo;
	}
	public void setTblo(String tblo) {
		this.tblo = tblo;
	}
	
	public  String getDriverClassName() {
		return driverClassName;
	}
	public void setDriverClassName(String driverClassName) {
		this.driverClassName = driverClassName;
	}
	
	public  String getIntBranchName() {
		return intBranchName;
	}
	public void setIntBranchName(String intBranchName) {
		this.intBranchName = intBranchName;
	}
}
