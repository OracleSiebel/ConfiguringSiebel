1. This Rest service is used to connect BUGZILLA to fetch details and update fields.
2. This implementation is done in Python language.
3. bugzillrest.py is file which defines URL details for various REST calls.
	- # GET URL - http://<hostname>:<port>/bugzillarest/bugs/<bug#>
	- # FIELDS URL - http://<hostname>:<port>/bugzillarest/fields
	- # POST URL - http://<hostname>:<port>/bugzillarest/bugs
4. bugzillaconnect.py files conatins details to connect BUGZILLA database.

